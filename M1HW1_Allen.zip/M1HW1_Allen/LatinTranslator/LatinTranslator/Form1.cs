﻿/**
* 01/31/2018
* CSC 153
* Nicholas M. Allen
* Latin to English translator
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LatinTranslator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void sinisterButton_Click(object sender, EventArgs e)
        {
            englishLabel.Text = "left";
        }

        private void dexterButton_Click(object sender, EventArgs e)
        {
            englishLabel.Text = "right";
        }

        private void mediumButton_Click(object sender, EventArgs e)
        {
            englishLabel.Text = "center";
        }
    }
}
