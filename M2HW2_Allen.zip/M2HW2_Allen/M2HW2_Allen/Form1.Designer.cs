﻿namespace M2HW2_Allen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.upperCaseAButton = new System.Windows.Forms.Button();
            this.lowerCaseaButton = new System.Windows.Forms.Button();
            this.upperCaseAnButton = new System.Windows.Forms.Button();
            this.lowerCaseanButton = new System.Windows.Forms.Button();
            this.upperCaseTheButton = new System.Windows.Forms.Button();
            this.lowerCasetheButton = new System.Windows.Forms.Button();
            this.manButton = new System.Windows.Forms.Button();
            this.womanButton = new System.Windows.Forms.Button();
            this.dogButton = new System.Windows.Forms.Button();
            this.catButton = new System.Windows.Forms.Button();
            this.carButton = new System.Windows.Forms.Button();
            this.bicycleButton = new System.Windows.Forms.Button();
            this.beautifulButton = new System.Windows.Forms.Button();
            this.bigButton = new System.Windows.Forms.Button();
            this.smallButton = new System.Windows.Forms.Button();
            this.strangeButton = new System.Windows.Forms.Button();
            this.lookedAtButton = new System.Windows.Forms.Button();
            this.rodeButton = new System.Windows.Forms.Button();
            this.spokeToButton = new System.Windows.Forms.Button();
            this.laughedAtButton = new System.Windows.Forms.Button();
            this.droveButton = new System.Windows.Forms.Button();
            this.spaceButton = new System.Windows.Forms.Button();
            this.periodButton = new System.Windows.Forms.Button();
            this.exclamationButton = new System.Windows.Forms.Button();
            this.sentenceLabel = new System.Windows.Forms.Label();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // upperCaseAButton
            // 
            this.upperCaseAButton.AutoSize = true;
            this.upperCaseAButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.upperCaseAButton.Location = new System.Drawing.Point(42, 21);
            this.upperCaseAButton.Name = "upperCaseAButton";
            this.upperCaseAButton.Size = new System.Drawing.Size(24, 23);
            this.upperCaseAButton.TabIndex = 0;
            this.upperCaseAButton.Text = "A";
            this.upperCaseAButton.UseVisualStyleBackColor = true;
            this.upperCaseAButton.Click += new System.EventHandler(this.upperCaseAButton_Click);
            // 
            // lowerCaseaButton
            // 
            this.lowerCaseaButton.AutoSize = true;
            this.lowerCaseaButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.lowerCaseaButton.Location = new System.Drawing.Point(80, 21);
            this.lowerCaseaButton.Name = "lowerCaseaButton";
            this.lowerCaseaButton.Size = new System.Drawing.Size(23, 23);
            this.lowerCaseaButton.TabIndex = 1;
            this.lowerCaseaButton.Text = "a";
            this.lowerCaseaButton.UseVisualStyleBackColor = true;
            this.lowerCaseaButton.Click += new System.EventHandler(this.lowerCaseaButton_Click);
            // 
            // upperCaseAnButton
            // 
            this.upperCaseAnButton.AutoSize = true;
            this.upperCaseAnButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.upperCaseAnButton.Location = new System.Drawing.Point(123, 21);
            this.upperCaseAnButton.Name = "upperCaseAnButton";
            this.upperCaseAnButton.Size = new System.Drawing.Size(30, 23);
            this.upperCaseAnButton.TabIndex = 2;
            this.upperCaseAnButton.Text = "An";
            this.upperCaseAnButton.UseVisualStyleBackColor = true;
            this.upperCaseAnButton.Click += new System.EventHandler(this.upperCaseAnButton_Click);
            // 
            // lowerCaseanButton
            // 
            this.lowerCaseanButton.AutoSize = true;
            this.lowerCaseanButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.lowerCaseanButton.Location = new System.Drawing.Point(163, 21);
            this.lowerCaseanButton.Name = "lowerCaseanButton";
            this.lowerCaseanButton.Size = new System.Drawing.Size(29, 23);
            this.lowerCaseanButton.TabIndex = 3;
            this.lowerCaseanButton.Text = "an";
            this.lowerCaseanButton.UseVisualStyleBackColor = true;
            this.lowerCaseanButton.Click += new System.EventHandler(this.lowerCaseanButton_Click);
            // 
            // upperCaseTheButton
            // 
            this.upperCaseTheButton.AutoSize = true;
            this.upperCaseTheButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.upperCaseTheButton.Location = new System.Drawing.Point(206, 21);
            this.upperCaseTheButton.Name = "upperCaseTheButton";
            this.upperCaseTheButton.Size = new System.Drawing.Size(36, 23);
            this.upperCaseTheButton.TabIndex = 4;
            this.upperCaseTheButton.Text = "The";
            this.upperCaseTheButton.UseVisualStyleBackColor = true;
            this.upperCaseTheButton.Click += new System.EventHandler(this.upperCaseTheButton_Click);
            // 
            // lowerCasetheButton
            // 
            this.lowerCasetheButton.AutoSize = true;
            this.lowerCasetheButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.lowerCasetheButton.Location = new System.Drawing.Point(248, 21);
            this.lowerCasetheButton.Name = "lowerCasetheButton";
            this.lowerCasetheButton.Size = new System.Drawing.Size(32, 23);
            this.lowerCasetheButton.TabIndex = 5;
            this.lowerCasetheButton.Text = "the";
            this.lowerCasetheButton.UseVisualStyleBackColor = true;
            this.lowerCasetheButton.Click += new System.EventHandler(this.lowerCasetheButton_Click);
            // 
            // manButton
            // 
            this.manButton.AutoSize = true;
            this.manButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.manButton.Location = new System.Drawing.Point(9, 52);
            this.manButton.Name = "manButton";
            this.manButton.Size = new System.Drawing.Size(37, 23);
            this.manButton.TabIndex = 6;
            this.manButton.Text = "man";
            this.manButton.UseVisualStyleBackColor = true;
            this.manButton.Click += new System.EventHandler(this.manButton_Click);
            // 
            // womanButton
            // 
            this.womanButton.AutoSize = true;
            this.womanButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.womanButton.Location = new System.Drawing.Point(52, 50);
            this.womanButton.Name = "womanButton";
            this.womanButton.Size = new System.Drawing.Size(51, 23);
            this.womanButton.TabIndex = 7;
            this.womanButton.Text = "woman";
            this.womanButton.UseVisualStyleBackColor = true;
            this.womanButton.Click += new System.EventHandler(this.womanButton_Click);
            // 
            // dogButton
            // 
            this.dogButton.AutoSize = true;
            this.dogButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.dogButton.Location = new System.Drawing.Point(118, 52);
            this.dogButton.Name = "dogButton";
            this.dogButton.Size = new System.Drawing.Size(35, 23);
            this.dogButton.TabIndex = 8;
            this.dogButton.Text = "dog";
            this.dogButton.UseVisualStyleBackColor = true;
            this.dogButton.Click += new System.EventHandler(this.dogButton_Click);
            // 
            // catButton
            // 
            this.catButton.AutoSize = true;
            this.catButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.catButton.Location = new System.Drawing.Point(163, 52);
            this.catButton.Name = "catButton";
            this.catButton.Size = new System.Drawing.Size(32, 23);
            this.catButton.TabIndex = 9;
            this.catButton.Text = "cat";
            this.catButton.UseVisualStyleBackColor = true;
            this.catButton.Click += new System.EventHandler(this.catButton_Click);
            // 
            // carButton
            // 
            this.carButton.AutoSize = true;
            this.carButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.carButton.Location = new System.Drawing.Point(206, 52);
            this.carButton.Name = "carButton";
            this.carButton.Size = new System.Drawing.Size(32, 23);
            this.carButton.TabIndex = 10;
            this.carButton.Text = "car";
            this.carButton.UseVisualStyleBackColor = true;
            this.carButton.Click += new System.EventHandler(this.carButton_Click);
            // 
            // bicycleButton
            // 
            this.bicycleButton.AutoSize = true;
            this.bicycleButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bicycleButton.Location = new System.Drawing.Point(249, 50);
            this.bicycleButton.Name = "bicycleButton";
            this.bicycleButton.Size = new System.Drawing.Size(50, 23);
            this.bicycleButton.TabIndex = 11;
            this.bicycleButton.Text = "bicycle";
            this.bicycleButton.UseVisualStyleBackColor = true;
            this.bicycleButton.Click += new System.EventHandler(this.bicycleButton_Click);
            // 
            // beautifulButton
            // 
            this.beautifulButton.AutoSize = true;
            this.beautifulButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.beautifulButton.Location = new System.Drawing.Point(52, 79);
            this.beautifulButton.Name = "beautifulButton";
            this.beautifulButton.Size = new System.Drawing.Size(57, 23);
            this.beautifulButton.TabIndex = 12;
            this.beautifulButton.Text = "beautiful";
            this.beautifulButton.UseVisualStyleBackColor = true;
            this.beautifulButton.Click += new System.EventHandler(this.beautifulButton_Click);
            // 
            // bigButton
            // 
            this.bigButton.AutoSize = true;
            this.bigButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.bigButton.Location = new System.Drawing.Point(122, 79);
            this.bigButton.Name = "bigButton";
            this.bigButton.Size = new System.Drawing.Size(31, 23);
            this.bigButton.TabIndex = 13;
            this.bigButton.Text = "big";
            this.bigButton.UseVisualStyleBackColor = true;
            this.bigButton.Click += new System.EventHandler(this.bigButton_Click);
            // 
            // smallButton
            // 
            this.smallButton.AutoSize = true;
            this.smallButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.smallButton.Location = new System.Drawing.Point(163, 79);
            this.smallButton.Name = "smallButton";
            this.smallButton.Size = new System.Drawing.Size(40, 23);
            this.smallButton.TabIndex = 14;
            this.smallButton.Text = "small";
            this.smallButton.UseVisualStyleBackColor = true;
            this.smallButton.Click += new System.EventHandler(this.smallButton_Click);
            // 
            // strangeButton
            // 
            this.strangeButton.AutoSize = true;
            this.strangeButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.strangeButton.Location = new System.Drawing.Point(209, 79);
            this.strangeButton.Name = "strangeButton";
            this.strangeButton.Size = new System.Drawing.Size(52, 23);
            this.strangeButton.TabIndex = 15;
            this.strangeButton.Text = "strange";
            this.strangeButton.UseVisualStyleBackColor = true;
            this.strangeButton.Click += new System.EventHandler(this.strangeButton_Click);
            // 
            // lookedAtButton
            // 
            this.lookedAtButton.AutoSize = true;
            this.lookedAtButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.lookedAtButton.Location = new System.Drawing.Point(18, 108);
            this.lookedAtButton.Name = "lookedAtButton";
            this.lookedAtButton.Size = new System.Drawing.Size(61, 23);
            this.lookedAtButton.TabIndex = 16;
            this.lookedAtButton.Text = "looked at";
            this.lookedAtButton.UseVisualStyleBackColor = true;
            this.lookedAtButton.Click += new System.EventHandler(this.lookedAtButton_Click);
            // 
            // rodeButton
            // 
            this.rodeButton.AutoSize = true;
            this.rodeButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.rodeButton.Location = new System.Drawing.Point(91, 108);
            this.rodeButton.Name = "rodeButton";
            this.rodeButton.Size = new System.Drawing.Size(38, 23);
            this.rodeButton.TabIndex = 17;
            this.rodeButton.Text = "rode";
            this.rodeButton.UseVisualStyleBackColor = true;
            this.rodeButton.Click += new System.EventHandler(this.rodeButton_Click);
            // 
            // spokeToButton
            // 
            this.spokeToButton.AutoSize = true;
            this.spokeToButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.spokeToButton.Location = new System.Drawing.Point(139, 108);
            this.spokeToButton.Name = "spokeToButton";
            this.spokeToButton.Size = new System.Drawing.Size(58, 23);
            this.spokeToButton.TabIndex = 18;
            this.spokeToButton.Text = "spoke to";
            this.spokeToButton.UseVisualStyleBackColor = true;
            this.spokeToButton.Click += new System.EventHandler(this.spokeToButton_Click);
            // 
            // laughedAtButton
            // 
            this.laughedAtButton.AutoSize = true;
            this.laughedAtButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.laughedAtButton.Location = new System.Drawing.Point(208, 108);
            this.laughedAtButton.Name = "laughedAtButton";
            this.laughedAtButton.Size = new System.Drawing.Size(67, 23);
            this.laughedAtButton.TabIndex = 19;
            this.laughedAtButton.Text = "laughed at";
            this.laughedAtButton.UseVisualStyleBackColor = true;
            this.laughedAtButton.Click += new System.EventHandler(this.laughedAtButton_Click);
            // 
            // droveButton
            // 
            this.droveButton.AutoSize = true;
            this.droveButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.droveButton.Location = new System.Drawing.Point(281, 108);
            this.droveButton.Name = "droveButton";
            this.droveButton.Size = new System.Drawing.Size(44, 23);
            this.droveButton.TabIndex = 20;
            this.droveButton.Text = "drove";
            this.droveButton.UseVisualStyleBackColor = true;
            this.droveButton.Click += new System.EventHandler(this.droveButton_Click);
            // 
            // spaceButton
            // 
            this.spaceButton.AutoSize = true;
            this.spaceButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.spaceButton.Location = new System.Drawing.Point(99, 137);
            this.spaceButton.Name = "spaceButton";
            this.spaceButton.Size = new System.Drawing.Size(54, 23);
            this.spaceButton.TabIndex = 21;
            this.spaceButton.Text = "(Space)";
            this.spaceButton.UseVisualStyleBackColor = true;
            this.spaceButton.Click += new System.EventHandler(this.spaceButton_Click);
            // 
            // periodButton
            // 
            this.periodButton.AutoSize = true;
            this.periodButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.periodButton.Location = new System.Drawing.Point(167, 137);
            this.periodButton.Name = "periodButton";
            this.periodButton.Size = new System.Drawing.Size(20, 23);
            this.periodButton.TabIndex = 22;
            this.periodButton.Text = ".";
            this.periodButton.UseVisualStyleBackColor = true;
            this.periodButton.Click += new System.EventHandler(this.periodButton_Click);
            // 
            // exclamationButton
            // 
            this.exclamationButton.AutoSize = true;
            this.exclamationButton.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.exclamationButton.Location = new System.Drawing.Point(202, 137);
            this.exclamationButton.Name = "exclamationButton";
            this.exclamationButton.Size = new System.Drawing.Size(20, 23);
            this.exclamationButton.TabIndex = 23;
            this.exclamationButton.Text = "!";
            this.exclamationButton.UseVisualStyleBackColor = true;
            this.exclamationButton.Click += new System.EventHandler(this.exclamationButton_Click);
            // 
            // sentenceLabel
            // 
            this.sentenceLabel.BackColor = System.Drawing.SystemColors.Control;
            this.sentenceLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.sentenceLabel.ForeColor = System.Drawing.SystemColors.ControlText;
            this.sentenceLabel.Location = new System.Drawing.Point(10, 163);
            this.sentenceLabel.Name = "sentenceLabel";
            this.sentenceLabel.Size = new System.Drawing.Size(312, 23);
            this.sentenceLabel.TabIndex = 24;
            this.sentenceLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(100, 189);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(70, 23);
            this.clearButton.TabIndex = 25;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(175, 189);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 26;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(334, 216);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.sentenceLabel);
            this.Controls.Add(this.exclamationButton);
            this.Controls.Add(this.periodButton);
            this.Controls.Add(this.spaceButton);
            this.Controls.Add(this.droveButton);
            this.Controls.Add(this.laughedAtButton);
            this.Controls.Add(this.spokeToButton);
            this.Controls.Add(this.rodeButton);
            this.Controls.Add(this.lookedAtButton);
            this.Controls.Add(this.strangeButton);
            this.Controls.Add(this.smallButton);
            this.Controls.Add(this.bigButton);
            this.Controls.Add(this.beautifulButton);
            this.Controls.Add(this.bicycleButton);
            this.Controls.Add(this.carButton);
            this.Controls.Add(this.catButton);
            this.Controls.Add(this.dogButton);
            this.Controls.Add(this.womanButton);
            this.Controls.Add(this.manButton);
            this.Controls.Add(this.lowerCasetheButton);
            this.Controls.Add(this.upperCaseTheButton);
            this.Controls.Add(this.lowerCaseanButton);
            this.Controls.Add(this.upperCaseAnButton);
            this.Controls.Add(this.lowerCaseaButton);
            this.Controls.Add(this.upperCaseAButton);
            this.Name = "Form1";
            this.Text = "Sentence Builder";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button upperCaseAButton;
        private System.Windows.Forms.Button lowerCaseaButton;
        private System.Windows.Forms.Button upperCaseAnButton;
        private System.Windows.Forms.Button lowerCaseanButton;
        private System.Windows.Forms.Button upperCaseTheButton;
        private System.Windows.Forms.Button lowerCasetheButton;
        private System.Windows.Forms.Button manButton;
        private System.Windows.Forms.Button womanButton;
        private System.Windows.Forms.Button dogButton;
        private System.Windows.Forms.Button catButton;
        private System.Windows.Forms.Button carButton;
        private System.Windows.Forms.Button bicycleButton;
        private System.Windows.Forms.Button beautifulButton;
        private System.Windows.Forms.Button bigButton;
        private System.Windows.Forms.Button smallButton;
        private System.Windows.Forms.Button strangeButton;
        private System.Windows.Forms.Button lookedAtButton;
        private System.Windows.Forms.Button rodeButton;
        private System.Windows.Forms.Button spokeToButton;
        private System.Windows.Forms.Button laughedAtButton;
        private System.Windows.Forms.Button droveButton;
        private System.Windows.Forms.Button spaceButton;
        private System.Windows.Forms.Button periodButton;
        private System.Windows.Forms.Button exclamationButton;
        private System.Windows.Forms.Label sentenceLabel;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
    }
}

