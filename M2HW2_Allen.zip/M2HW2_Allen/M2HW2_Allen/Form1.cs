﻿/**
 * 02/12/2018
 * CSC 153
 * Nicholas M. Allen
 * Builds a sentence based on user selected buttons
 */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2HW2_Allen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // This button will clear the sentence label
            sentenceLabel.Text = "";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // This button closes the form
            this.Close();
        }

        private void upperCaseAButton_Click(object sender, EventArgs e)
        {
            // This button adds an "An" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + upperCaseAButton.Text;
        }

        private void lowerCaseaButton_Click(object sender, EventArgs e)
        {
            // This adds "a" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + lowerCaseaButton.Text;
        }

        private void upperCaseAnButton_Click(object sender, EventArgs e)
        {
            // This adds "An" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + upperCaseAnButton.Text;
        }

        private void lowerCaseanButton_Click(object sender, EventArgs e)
        {
            // This adds "an" to the sentece 
            sentenceLabel.Text = sentenceLabel.Text + lowerCaseanButton.Text;
        }

        private void upperCaseTheButton_Click(object sender, EventArgs e)
        {
            // This adds "The" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + upperCaseTheButton.Text;
        }

        private void lowerCasetheButton_Click(object sender, EventArgs e)
        {
            // This adds "the" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + lowerCasetheButton.Text;
        }

        private void manButton_Click(object sender, EventArgs e)
        {
            // This adds "man" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + manButton.Text;
        }

        private void womanButton_Click(object sender, EventArgs e)
        {
            // This adds "woman" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + womanButton.Text;
        }

        private void dogButton_Click(object sender, EventArgs e)
        {
            // This adds "dog" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + dogButton.Text;
        }

        private void catButton_Click(object sender, EventArgs e)
        {
            // This adds "cat" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + catButton.Text;
        }

        private void carButton_Click(object sender, EventArgs e)
        {
            // This adds "car" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + carButton.Text;
        }

        private void bicycleButton_Click(object sender, EventArgs e)
        {
            // This adds "bicycle" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + bicycleButton.Text;
        }

        private void beautifulButton_Click(object sender, EventArgs e)
        {
            // This adds "beautiful" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + beautifulButton.Text;
        }

        private void bigButton_Click(object sender, EventArgs e)
        {
            // This adds "big" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + bigButton.Text;
        }

        private void smallButton_Click(object sender, EventArgs e)
        {
            // This adds "small" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + smallButton.Text;
        }

        private void strangeButton_Click(object sender, EventArgs e)
        {
            // This adds "strange" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + strangeButton.Text;
        }

        private void lookedAtButton_Click(object sender, EventArgs e)
        {
            // This adds "looked at" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + lookedAtButton.Text;
        }

        private void rodeButton_Click(object sender, EventArgs e)
        {
            // This adds "rode" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + rodeButton.Text;
        }

        private void spokeToButton_Click(object sender, EventArgs e)
        {
            // This adds "spoke to" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + spokeToButton.Text;
        }

        private void laughedAtButton_Click(object sender, EventArgs e)
        {
            // This adds "laughed at" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + laughedAtButton.Text;
        }

        private void droveButton_Click(object sender, EventArgs e)
        {
            // This adds "drove" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + droveButton.Text;
        }

        private void spaceButton_Click(object sender, EventArgs e)
        {
            // This adds " " to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + " ";
        }

        private void periodButton_Click(object sender, EventArgs e)
        {
            // This adds "." to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + ".";
        }

        private void exclamationButton_Click(object sender, EventArgs e)
        {
            // This adds "!" to the sentence label
            sentenceLabel.Text = sentenceLabel.Text + "!";
        }
    }
}
