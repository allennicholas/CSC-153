﻿/**
* September 27, 2018
* CSC 253
* Nicholas M. Allen
* Display how many times each team has
* won the world series
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace M2HW2_Allen
{
    public partial class Form1 : Form
    {
        List<string> teamsList = new List<string>();

        public Form1()
        {
            InitializeComponent();
        }

        private void ReadTeams(List<string> teamsList)
        {
            try
            {
                StreamReader inputFile = File.OpenText("WorldSeriesWinners.txt");

                while (!inputFile.EndOfStream)
                {
                    teamsList.Add(inputFile.ReadLine());
                }
                
                inputFile.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void checkWinsButton_Click(object sender, EventArgs e)
        {
            string teamName = teamNameTextBox.Text; // Placeholder for team entry
            int winCount = 0; // Placeholder for number of wins
            
            foreach(string name in teamsList)
            {
                if (name == teamName)
                {
                    winCount++;
                    numOfWinsLabel.Text = winCount.ToString();
                } else
                {
                    if (winCount == 0) {
                        numOfWinsLabel.Text = "This team has never won";
                    }
                }

               
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            ReadTeams(teamsList);
        }
    }
}
