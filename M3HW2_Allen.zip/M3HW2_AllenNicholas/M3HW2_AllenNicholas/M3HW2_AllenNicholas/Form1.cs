﻿/**
* 02/28/2018
* CSC 153
* Nicholas M. Allen
* Software sales discount calculator
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW2_AllenNicholas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            int count = Convert.ToInt32(Math.Round(amountofSoftwarePurchased.Value, 0));    // Gets the number
            int PRICE = 99;                                                                 // Price of the software title is constant
            
            double discount = 0;                                                            // Placeholder for discount math

            // Shows the discounts for amount of software purchased

            // Shows the discount for upto 9 licenses
            if (amountofSoftwarePurchased.Value <= 9)
            {
                int amount = 0;

                amount = count * PRICE;
                amount.ToString();

                discountLbl.Text = "NONE";

                totalPurchaseAmountLbl.Text = "$" + amount;
            }
            // Shows the discount for between 10 and 19 licenses
            else if (amountofSoftwarePurchased.Value <= 19)
            {
                double discountTwenty = 0;
                double twentyPercent = .20;

                discountTwenty = PRICE - (PRICE * twentyPercent);
                discount = count * discountTwenty;

                discount.ToString();

                discountLbl.Text = "20%";
                totalPurchaseAmountLbl.Text = "$" + discount;
            }
            // Shows the discount for between 20 and 49 licenses
            else if (amountofSoftwarePurchased.Value <= 49)
            {
                double discountThirty = 0;
                double thirtyPercent = .30;

                discountThirty = PRICE - (PRICE * thirtyPercent);
                discount = count * discountThirty;

                discount.ToString();

                discountLbl.Text = "30%";
                totalPurchaseAmountLbl.Text = "$" + discount;
            }
            // Shows the discount for between 50 and 99 licenses
            else if (amountofSoftwarePurchased.Value <= 99)
            {
                double discountFourty = 0;
                double fourtyPercent = .40;

                discountFourty = PRICE - (PRICE * fourtyPercent);
                discount = count * discountFourty;

                discount.ToString();

                discountLbl.Text = "40%";
                totalPurchaseAmountLbl.Text = "$" + discount;
            }
            // Shows the discount for over 100 licenses
            else if (amountofSoftwarePurchased.Value >= 100)
            {
                double discountFifty = 0;
                double fiftyPercent = .50;

                discountFifty = PRICE - (PRICE * fiftyPercent);
                discount = count * discountFifty;

                discount.ToString();

                discountLbl.Text = "50%";
                totalPurchaseAmountLbl.Text = "$" + discount;
            }
        }
    }
}
