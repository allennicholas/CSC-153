﻿/**
* 05/13/2018
* CSC 153
* Nicholas M. Allen
* Controlling a cars speed with buttons
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP2_Allen
{
    public partial class Form1 : Form
    {
        // This is my own car
        private Car car = new Car(2018, "Dodge");

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Display the car year in the year label
            yearLabel.Text = car.Year.ToString();

            // Display the car make in the make label
            makeLabel.Text = car.Make;

            // Display the car speed in the speed label
            speedLabel.Text = car.Speed.ToString();
        }

        private void accelerateButton_Click(object sender, EventArgs e)
        {
            // Run accelerate method in Car.cs
            car.accerlerate();

            // update the speed label
            speedLabel.Text = car.Speed.ToString("0");
        }

        private void brakeButton_Click(object sender, EventArgs e)
        {
            // if speed is already 0
            if (car.Speed == 0)
            {
                MessageBox.Show("Speed can't be less than zero");
            }
            else
            {
                // Run brake method in Car.cs
                car.brake();

                // update the speed label
                speedLabel.Text = car.Speed.ToString("0");
            
            }
        }
    }
}
