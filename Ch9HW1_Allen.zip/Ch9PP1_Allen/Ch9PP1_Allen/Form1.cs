﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP1_Allen
{
    public partial class Form1 : Form
    {
        // List to hold Animal objects
        List<Pet> animalList = new List<Pet>();

        public Form1()
        {
            InitializeComponent();
        }

        private void GetAnimalData(Pet animal)
        {
            // Get the animal's name
            animal.Name = nameTextBox.Text;

            // Get the animal type
            animal.Type = typeTextBox.Text;

            // get the animals' age
            animal.Age = int.Parse(ageTextBox.Text);

        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }

        private void addButton_Click(object sender, EventArgs e)
        {
            // Create a Pet object
            Pet animal = new Pet();

            // Get the animal data.
            GetAnimalData(animal);

            // Add the Pet object to the List.
            animalList.Add(animal);

            // Add an entry to the list box
            animalListBox.Items.Add(animal.Name + " " + animal.Type);

            // Clear the TextBox controls.
            nameTextBox.Clear();
            typeTextBox.Clear();
            ageTextBox.Clear();

            // Reset the focus.
            nameTextBox.Focus();
        }

        private void animalListBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Get the index of the selected item.
            int index = animalListBox.SelectedIndex;

            // Display the select animals age
            MessageBox.Show(animalList[index].Age.ToString());
        }
    }
}
