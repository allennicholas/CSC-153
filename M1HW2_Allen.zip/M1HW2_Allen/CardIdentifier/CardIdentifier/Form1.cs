﻿/**
* 01/31/2018
* CSC 153
* Nicholas M. Allen
* Click card to display written out name of card
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CardIdentifier
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void aceSpadesPictureBox_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Ace of Spades";
        }

        private void nineClubsPictureBox_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Nine of Clubs";
        }

        private void tenHeartsPictureBox_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Ten of Hearts";
        }

        private void nineSpadesPictureBox_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Nine of Spades";
        }

        private void sixSpadesPictureBox_Click(object sender, EventArgs e)
        {
            cardNameLabel.Text = "Six of Spades";
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
