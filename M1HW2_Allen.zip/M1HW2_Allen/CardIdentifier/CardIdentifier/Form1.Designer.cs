﻿namespace CardIdentifier
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.aceSpadesPictureBox = new System.Windows.Forms.PictureBox();
            this.sixSpadesPictureBox = new System.Windows.Forms.PictureBox();
            this.nineSpadesPictureBox = new System.Windows.Forms.PictureBox();
            this.nineClubsPictureBox = new System.Windows.Forms.PictureBox();
            this.tenHeartsPictureBox = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.cardNameLabel = new System.Windows.Forms.Label();
            this.exitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.aceSpadesPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixSpadesPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nineSpadesPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.nineClubsPictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenHeartsPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // aceSpadesPictureBox
            // 
            this.aceSpadesPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("aceSpadesPictureBox.Image")));
            this.aceSpadesPictureBox.Location = new System.Drawing.Point(12, 58);
            this.aceSpadesPictureBox.Name = "aceSpadesPictureBox";
            this.aceSpadesPictureBox.Size = new System.Drawing.Size(200, 250);
            this.aceSpadesPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.aceSpadesPictureBox.TabIndex = 0;
            this.aceSpadesPictureBox.TabStop = false;
            this.aceSpadesPictureBox.Click += new System.EventHandler(this.aceSpadesPictureBox_Click);
            // 
            // sixSpadesPictureBox
            // 
            this.sixSpadesPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("sixSpadesPictureBox.Image")));
            this.sixSpadesPictureBox.Location = new System.Drawing.Point(876, 58);
            this.sixSpadesPictureBox.Name = "sixSpadesPictureBox";
            this.sixSpadesPictureBox.Size = new System.Drawing.Size(200, 250);
            this.sixSpadesPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.sixSpadesPictureBox.TabIndex = 1;
            this.sixSpadesPictureBox.TabStop = false;
            this.sixSpadesPictureBox.Click += new System.EventHandler(this.sixSpadesPictureBox_Click);
            // 
            // nineSpadesPictureBox
            // 
            this.nineSpadesPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("nineSpadesPictureBox.Image")));
            this.nineSpadesPictureBox.Location = new System.Drawing.Point(660, 58);
            this.nineSpadesPictureBox.Name = "nineSpadesPictureBox";
            this.nineSpadesPictureBox.Size = new System.Drawing.Size(200, 250);
            this.nineSpadesPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.nineSpadesPictureBox.TabIndex = 2;
            this.nineSpadesPictureBox.TabStop = false;
            this.nineSpadesPictureBox.Click += new System.EventHandler(this.nineSpadesPictureBox_Click);
            // 
            // nineClubsPictureBox
            // 
            this.nineClubsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("nineClubsPictureBox.Image")));
            this.nineClubsPictureBox.Location = new System.Drawing.Point(227, 58);
            this.nineClubsPictureBox.Name = "nineClubsPictureBox";
            this.nineClubsPictureBox.Size = new System.Drawing.Size(200, 250);
            this.nineClubsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.nineClubsPictureBox.TabIndex = 3;
            this.nineClubsPictureBox.TabStop = false;
            this.nineClubsPictureBox.Click += new System.EventHandler(this.nineClubsPictureBox_Click);
            // 
            // tenHeartsPictureBox
            // 
            this.tenHeartsPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("tenHeartsPictureBox.Image")));
            this.tenHeartsPictureBox.Location = new System.Drawing.Point(442, 58);
            this.tenHeartsPictureBox.Name = "tenHeartsPictureBox";
            this.tenHeartsPictureBox.Size = new System.Drawing.Size(200, 250);
            this.tenHeartsPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.tenHeartsPictureBox.TabIndex = 4;
            this.tenHeartsPictureBox.TabStop = false;
            this.tenHeartsPictureBox.Click += new System.EventHandler(this.tenHeartsPictureBox_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(373, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(337, 24);
            this.label1.TabIndex = 5;
            this.label1.Text = "Select a card to display card name:";
            // 
            // cardNameLabel
            // 
            this.cardNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.cardNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cardNameLabel.Location = new System.Drawing.Point(261, 336);
            this.cardNameLabel.Name = "cardNameLabel";
            this.cardNameLabel.Size = new System.Drawing.Size(548, 23);
            this.cardNameLabel.TabIndex = 6;
            this.cardNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(505, 367);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 7;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1090, 402);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.cardNameLabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.tenHeartsPictureBox);
            this.Controls.Add(this.nineClubsPictureBox);
            this.Controls.Add(this.nineSpadesPictureBox);
            this.Controls.Add(this.sixSpadesPictureBox);
            this.Controls.Add(this.aceSpadesPictureBox);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.aceSpadesPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.sixSpadesPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nineSpadesPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.nineClubsPictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tenHeartsPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox aceSpadesPictureBox;
        private System.Windows.Forms.PictureBox sixSpadesPictureBox;
        private System.Windows.Forms.PictureBox nineSpadesPictureBox;
        private System.Windows.Forms.PictureBox nineClubsPictureBox;
        private System.Windows.Forms.PictureBox tenHeartsPictureBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label cardNameLabel;
        private System.Windows.Forms.Button exitButton;
    }
}

