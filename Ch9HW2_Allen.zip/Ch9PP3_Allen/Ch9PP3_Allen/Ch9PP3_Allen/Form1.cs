﻿/**
* 05-14-2018
* CSC 153
* Nicholas M. Allen
* Get infomation about Family and Friends Displayed
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ch9PP3_Allen
{
    public partial class Form1 : Form
    {
        private People[] familyMembers = new People[3];
        public Form1()
        {
            InitializeComponent();
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Will be loaded when form is launched

            // My information is Index 0
            familyMembers[0] = new People();
            familyMembers[0].Name = "Nick";
            familyMembers[0].Address = "511 Vass Carthage Rd";
            familyMembers[0].Age = 27;
            familyMembers[0].phoneNumber = "910-508-4952";

            // Mother information is Index 1
            familyMembers[1] = new People();
            familyMembers[1].Name = "Michelle";
            familyMembers[1].Address = "New York, NY";
            familyMembers[1].Age = 54;
            familyMembers[1].phoneNumber = "518-439-6451";

            // Girlfriend information is Index 2
            familyMembers[2] = new People();
            familyMembers[2].Name = "Jess";
            familyMembers[2].Address = "PO BOX 1092";
            familyMembers[2].Age = 21;
            familyMembers[2].phoneNumber = "910.503.4983";
        }

        private void displayInfoButton_Click(object sender, EventArgs e)
        {
            // Display the family information to the textboxes

            // my information
            infoAboutMeTextBox.Text = familyMembers[0].Name + " , " + familyMembers[0].Address + " , " +
                familyMembers[0].Age + " , " + familyMembers[0].phoneNumber;

            // my mothers infomation
            infoAboutMomTextBox.Text = familyMembers[1].Name + " , " + familyMembers[1].Address + "  , " +
                familyMembers[1].Age + " , " + familyMembers[1].phoneNumber;

            // my girlfriends information
            gfInfoTextBox.Text = familyMembers[2].Name + " , " + familyMembers[2].Address + " , " +
                familyMembers[2].Age + " , " + familyMembers[2].phoneNumber;
        }
    }
}
