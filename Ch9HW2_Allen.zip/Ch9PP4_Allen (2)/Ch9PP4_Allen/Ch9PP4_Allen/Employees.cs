﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9PP4_Allen
{
    class Employees
    {
        private string _name;
        private int _id;
        private string _department;
        private string _position;

        public Employees()
        {
            _name = "";
            _id = 0;
            _department = "";
            _position = "";
        }

        public Employees(string name, int id, string department, string position)
        {
            _name = name;
            _id = id;
            _department = department;
            _position = position;
        }

        public Employees(string name, int id)
        {
            _name = name;
            _id = id;
            _department = "";
            _position = "";
        }

        public string Name
        {
            set { _name = value; }
            get { return _name; }
        }

        public int Id
        {
            set { _id = value; }
            get { return _id; }
        }

        public string Department
        {
            set { _department = value; }
            get { return _department; }
        }

        public string Position
        {
            set { _position = value; }
            get { return _position; }
        }
    }
}
