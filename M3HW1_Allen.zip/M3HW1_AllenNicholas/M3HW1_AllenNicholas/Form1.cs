﻿/**
* 02/28/2018
* CSC 153
* Nicholas M. Allen
* Number to Roman numeral converter
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M3HW1_AllenNicholas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void numberTextBox_TextChanged(object sender, EventArgs e)
        {
            //numberTextBox.SelectAll();
        }

        // Gets the number inputted and displays the correct roman numeral
        private void displayRomanNumeralButton_Click(object sender, EventArgs e)
        {
            int number = Convert.ToInt32(numberTextBox.Text);
            switch (number)
            {
                // Displays the roman numeral for 1
                case 1:
                    romanNumeralLabel.Text = "I";
                    break;
                
                // Displays the roman numeral for 2
                case 2:
                    romanNumeralLabel.Text = "II";
                    break;
                
                // Displays the roman numeral for 3
                case 3:
                    romanNumeralLabel.Text = "III";
                    break;

                // Displays the roman numeral for 4
                case 4:
                    romanNumeralLabel.Text = "IV";
                    break;

                // Displays the roman numeral for 5
                case 5:
                    romanNumeralLabel.Text = "V";
                    break;

                // Displays the roman numeral for 6
                case 6:
                    romanNumeralLabel.Text = "VI";
                    break;

                // Displays the roman numeral for 7
                case 7:
                    romanNumeralLabel.Text = "VII";
                    break;

                // Displays the roman numeral for 8
                case 8:
                    romanNumeralLabel.Text = "VIII";
                    break;

                // Displays the roman numeral for 9
                case 9:
                    romanNumeralLabel.Text = "IX";
                    break;

                // Displays the roman numeral for 10
                case 10:
                    romanNumeralLabel.Text = "X";
                    break;

                // If the number inputted isn't between 1-10 throw error
                default:
                    MessageBox.Show("Error: Invalid number");
                    break;
            }
        }
    }
}
