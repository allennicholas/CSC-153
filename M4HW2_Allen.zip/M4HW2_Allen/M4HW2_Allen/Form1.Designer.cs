﻿namespace M4HW2_Allen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.label1 = new System.Windows.Forms.Label();
            this.rollDiceButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.diceOnePictureBox = new System.Windows.Forms.PictureBox();
            this.diceTwoPictureBox = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.diceOnePictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.diceTwoPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(181, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "DICE ROLLER";
            // 
            // rollDiceButton
            // 
            this.rollDiceButton.Location = new System.Drawing.Point(23, 148);
            this.rollDiceButton.Name = "rollDiceButton";
            this.rollDiceButton.Size = new System.Drawing.Size(75, 23);
            this.rollDiceButton.TabIndex = 3;
            this.rollDiceButton.Text = "Roll";
            this.rollDiceButton.UseVisualStyleBackColor = true;
            this.rollDiceButton.Click += new System.EventHandler(this.rollDiceButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(114, 148);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 4;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // diceOnePictureBox
            // 
            this.diceOnePictureBox.Image = global::M4HW2_Allen.Properties.Resources.two;
            this.diceOnePictureBox.Location = new System.Drawing.Point(23, 52);
            this.diceOnePictureBox.Name = "diceOnePictureBox";
            this.diceOnePictureBox.Size = new System.Drawing.Size(80, 80);
            this.diceOnePictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.diceOnePictureBox.TabIndex = 8;
            this.diceOnePictureBox.TabStop = false;
            // 
            // diceTwoPictureBox
            // 
            this.diceTwoPictureBox.Image = ((System.Drawing.Image)(resources.GetObject("diceTwoPictureBox.Image")));
            this.diceTwoPictureBox.Location = new System.Drawing.Point(109, 52);
            this.diceTwoPictureBox.Name = "diceTwoPictureBox";
            this.diceTwoPictureBox.Size = new System.Drawing.Size(80, 80);
            this.diceTwoPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.diceTwoPictureBox.TabIndex = 14;
            this.diceTwoPictureBox.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(212, 186);
            this.Controls.Add(this.diceTwoPictureBox);
            this.Controls.Add(this.diceOnePictureBox);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.rollDiceButton);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Dice Roller";
            ((System.ComponentModel.ISupportInitialize)(this.diceOnePictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.diceTwoPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button rollDiceButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.PictureBox diceOnePictureBox;
        private System.Windows.Forms.PictureBox diceTwoPictureBox;
    }
}

