﻿/* 
* Nicholas M. Allen
* CSC 153
* 3/19/2018
* Random Dice Roller
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW2_Allen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void rollDiceButton_Click(object sender, EventArgs e)
        {
            int diceShown;
            int dice2Shown;

            Random rand = new Random();

            diceShown = rand.Next(6) + 1;
            dice2Shown = rand.Next(6) + 1;

            if (diceShown == 1)
            {
                diceOnePictureBox.Image = M4HW2_Allen.Properties.Resources.one;
            } else if (diceShown == 2)
            {
                diceOnePictureBox.Image = M4HW2_Allen.Properties.Resources.two;
            } else if (diceShown == 3)
            {
                diceOnePictureBox.Image = M4HW2_Allen.Properties.Resources.three;
            } else if (diceShown == 4)
            {
                diceOnePictureBox.Image = M4HW2_Allen.Properties.Resources.four;
            } else if (diceShown == 5)
            {
                diceOnePictureBox.Image = M4HW2_Allen.Properties.Resources.five;
            } else if (diceShown == 6)
            {
                diceOnePictureBox.Image = M4HW2_Allen.Properties.Resources.six;
            }

            if (dice2Shown == 1)
            {
                diceTwoPictureBox.Image = M4HW2_Allen.Properties.Resources.one;
            }
            else if (dice2Shown == 2)
            {
                diceTwoPictureBox.Image = M4HW2_Allen.Properties.Resources.two;
            }
            else if (dice2Shown == 3)
            {
                diceTwoPictureBox.Image = M4HW2_Allen.Properties.Resources.three;
            }
            else if (dice2Shown == 4)
            {
                diceTwoPictureBox.Image = M4HW2_Allen.Properties.Resources.four;
            }
            else if (dice2Shown == 5)
            {
                diceTwoPictureBox.Image = M4HW2_Allen.Properties.Resources.five;
            }
            else if (dice2Shown == 6)
            {
                diceTwoPictureBox.Image = M4HW2_Allen.Properties.Resources.six;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}
