﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ch9PP1_Allen
{
    class Pet
    {
        // Fields
        private string _name;           // The animals name
        private string _type;           // The type of animal
        private int _age;            // Age of animal

        // Constructor
        public Pet()
        {
            _name = "";
            _type = "";
            _age = 0;
        }

        // Name property
        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        // Type property
        public string Type
        {
            get { return _type; }
            set { _type = value; }
        }

        // Age property
        public int Age
        {
            get { return _age; }
            set { _age = value; }
        }
    }
}