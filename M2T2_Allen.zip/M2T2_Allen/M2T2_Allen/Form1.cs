﻿/**
* 02/05/2018
* CSC 153
* Nicholas M. Allen
* Calculating test averages from user input
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M2T2_Allen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            try
            {
                double test1;   // To hold test score #1
                double test2;   // To hold test score #2
                double test3;   // To hold test score #3
                double average; // To hold the average test score

                test1 = double.Parse(test1TextBox.Text); // Changes test1 input to a double
                test2 = double.Parse(test2TextBox.Text); // Changes test2 input to a double
                test3 = double.Parse(test3TextBox.Text); // Changes test3 input to a double

                average = (test1 + test2 + test3) / 3.0; // Adds test1, test2 and test 3 together then divides by 3

                averageLabel.Text = average.ToString("n1"); // Shows the average with one decimal point
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); // Throws error message if anything other than numbers is submitted
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // This will reset the textboxes and labels to their original values
            test1TextBox.Text = "";
            test2TextBox.Text = "";
            test3TextBox.Text = "";
            averageLabel.Text = "";
        }
    }
}
