﻿namespace M4HW1_Allen
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.populationListBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.generatePopulationButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.startingPopTextBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.dailyIncreaseTextBox = new System.Windows.Forms.TextBox();
            this.numOfDays = new System.Windows.Forms.Label();
            this.numOfDaysTextBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // populationListBox
            // 
            this.populationListBox.FormattingEnabled = true;
            this.populationListBox.Location = new System.Drawing.Point(12, 110);
            this.populationListBox.Name = "populationListBox";
            this.populationListBox.Size = new System.Drawing.Size(260, 160);
            this.populationListBox.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(38, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(205, 20);
            this.label1.TabIndex = 1;
            this.label1.Text = "Population Approximator";
            // 
            // generatePopulationButton
            // 
            this.generatePopulationButton.Location = new System.Drawing.Point(42, 276);
            this.generatePopulationButton.Name = "generatePopulationButton";
            this.generatePopulationButton.Size = new System.Drawing.Size(75, 44);
            this.generatePopulationButton.TabIndex = 2;
            this.generatePopulationButton.Text = "Generate Population";
            this.generatePopulationButton.UseVisualStyleBackColor = true;
            this.generatePopulationButton.Click += new System.EventHandler(this.generatePopulationButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(167, 276);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 44);
            this.exitButton.TabIndex = 3;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 35);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(99, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "Starting Population:";
            // 
            // startingPopTextBox
            // 
            this.startingPopTextBox.Location = new System.Drawing.Point(118, 32);
            this.startingPopTextBox.Name = "startingPopTextBox";
            this.startingPopTextBox.Size = new System.Drawing.Size(115, 20);
            this.startingPopTextBox.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(88, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Daily % Increase:";
            // 
            // dailyIncreaseTextBox
            // 
            this.dailyIncreaseTextBox.Location = new System.Drawing.Point(118, 60);
            this.dailyIncreaseTextBox.Name = "dailyIncreaseTextBox";
            this.dailyIncreaseTextBox.Size = new System.Drawing.Size(115, 20);
            this.dailyIncreaseTextBox.TabIndex = 7;
            // 
            // numOfDays
            // 
            this.numOfDays.AutoSize = true;
            this.numOfDays.Location = new System.Drawing.Point(13, 90);
            this.numOfDays.Name = "numOfDays";
            this.numOfDays.Size = new System.Drawing.Size(86, 13);
            this.numOfDays.TabIndex = 8;
            this.numOfDays.Text = "Number of Days:";
            // 
            // numOfDaysTextBox
            // 
            this.numOfDaysTextBox.Location = new System.Drawing.Point(118, 87);
            this.numOfDaysTextBox.Name = "numOfDaysTextBox";
            this.numOfDaysTextBox.Size = new System.Drawing.Size(115, 20);
            this.numOfDaysTextBox.TabIndex = 9;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 327);
            this.Controls.Add(this.numOfDaysTextBox);
            this.Controls.Add(this.numOfDays);
            this.Controls.Add(this.dailyIncreaseTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.startingPopTextBox);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.generatePopulationButton);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.populationListBox);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox populationListBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button generatePopulationButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox startingPopTextBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox dailyIncreaseTextBox;
        private System.Windows.Forms.Label numOfDays;
        private System.Windows.Forms.TextBox numOfDaysTextBox;
    }
}

