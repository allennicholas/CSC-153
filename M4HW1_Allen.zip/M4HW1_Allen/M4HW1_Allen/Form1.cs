﻿/* 
* Nicholas M. Allen
* CSC 153
* 3/12/2018
* Population Approximator with user input
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M4HW1_Allen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void generatePopulationButton_Click(object sender, EventArgs e)
        {
            double population = double.Parse(startingPopTextBox.Text);
            double numOfDays = double.Parse(numOfDaysTextBox.Text);
            double percentage = double.Parse(dailyIncreaseTextBox.Text);

            double dailyIncrease = (percentage / 100) + 1;
            var day = 0;

            for (day = 1; day <= numOfDays; day += 1)
            {
                if (day == 1)
                {
                    populationListBox.Items.Add("On Day " + day + " the population will be " + double.Parse(startingPopTextBox.Text) + ".");
                } else if (day > 1)
                {
                    population = population * dailyIncrease;
                    populationListBox.Items.Add("On Day " + day + " the population will be " + population + ".");
                } 
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close the form.
            this.Close();
        }
    }
}
