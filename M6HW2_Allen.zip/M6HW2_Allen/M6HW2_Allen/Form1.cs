﻿/**
* 04/16/2018
* CSC 153
* Nicholas M. Allen
* Calculates and Displays Total for Automotive Services
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW2_Allen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        double total = 0;
        double tax = .06;

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            oilCheckBox.Checked = false;
            lubeCheckBox.Checked = false;
            radiatorCheckBox.Checked = false;
            transmissionCheckBox.Checked = false;
            replaceMufflerCheckBox.Checked = false;
            tireRotationCheckBox.Checked = false;
            inspectionCheckBox.Checked = false;
            partsAmountTextBox.Text = "";
            laborAmountTextBox.Text = "";
            serviceLaborLabel.Text = "";
            partsLabel.Text = "";
            taxLabel.Text = "";
            totalLabel.Text = "";

            calculateButton.Enabled = true;
        }

        public double oilLubeChange()
        {

            total = 0.0;

            if (oilCheckBox.Checked == true){
                total += 26.00;
            }

            if (lubeCheckBox.Checked == true)
            {
                total += 18.00;
            }

            return total;
        }

        public double flushes()
        {
            total = 0.0;

            if (radiatorCheckBox.Checked == true)
            {
                total += 30.00;
            }

            if (transmissionCheckBox.Checked == true)
            {
                total += 80.00;
            }

            return total;
        }

        public double misc()
        {
            total = 0.0;

            if (inspectionCheckBox.Checked == true)
            {
                total += 15.00;
            }

            if (replaceMufflerCheckBox.Checked == true)
            {
                total += 100.00;
            }

            if (tireRotationCheckBox.Checked == true)
            {
                total += 20.00;
            }

            return total;
        }

        public double taxes()
        {

            tax = Double.Parse(partsAmountTextBox.Text) * tax;

            return tax;
        }



        private void calculateButton_Click(object sender, EventArgs e)
        {
            double totalCharges = oilLubeChange();

            totalCharges += flushes();

            totalCharges += misc();

            serviceLaborLabel.Text = (Double.Parse(laborAmountTextBox.Text) + totalCharges).ToString();

            totalCharges += taxes();

            partsLabel.Text = partsAmountTextBox.Text;
            taxLabel.Text = tax.ToString();
            totalLabel.Text = (Double.Parse(partsLabel.Text) + Double.Parse(laborAmountTextBox.Text) + totalCharges).ToString();
           

            calculateButton.Enabled = false;
        }
    }
}
