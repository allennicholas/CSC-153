﻿namespace WindowsFormsApplication1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.firstNamePromptLabel = new System.Windows.Forms.Label();
            this.middleNamePromptLabel = new System.Windows.Forms.Label();
            this.lastNamePromptLabel = new System.Windows.Forms.Label();
            this.firstNameTextBox = new System.Windows.Forms.TextBox();
            this.middleNameTextBox = new System.Windows.Forms.TextBox();
            this.lastNameTextBox = new System.Windows.Forms.TextBox();
            this.formattedNameLabel = new System.Windows.Forms.Label();
            this.formattedNameButton = new System.Windows.Forms.Button();
            this.clearButton = new System.Windows.Forms.Button();
            this.exitButton = new System.Windows.Forms.Button();
            this.nameFormattedLabel = new System.Windows.Forms.Label();
            this.titlePromptLabel = new System.Windows.Forms.Label();
            this.titleComboBox = new System.Windows.Forms.ComboBox();
            this.formatComboBox = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // firstNamePromptLabel
            // 
            this.firstNamePromptLabel.AutoSize = true;
            this.firstNamePromptLabel.Location = new System.Drawing.Point(13, 50);
            this.firstNamePromptLabel.Name = "firstNamePromptLabel";
            this.firstNamePromptLabel.Size = new System.Drawing.Size(58, 13);
            this.firstNamePromptLabel.TabIndex = 0;
            this.firstNamePromptLabel.Text = "First name:";
            // 
            // middleNamePromptLabel
            // 
            this.middleNamePromptLabel.AutoSize = true;
            this.middleNamePromptLabel.Location = new System.Drawing.Point(12, 80);
            this.middleNamePromptLabel.Name = "middleNamePromptLabel";
            this.middleNamePromptLabel.Size = new System.Drawing.Size(70, 13);
            this.middleNamePromptLabel.TabIndex = 1;
            this.middleNamePromptLabel.Text = "Middle name:";
            // 
            // lastNamePromptLabel
            // 
            this.lastNamePromptLabel.AutoSize = true;
            this.lastNamePromptLabel.Location = new System.Drawing.Point(13, 110);
            this.lastNamePromptLabel.Name = "lastNamePromptLabel";
            this.lastNamePromptLabel.Size = new System.Drawing.Size(59, 13);
            this.lastNamePromptLabel.TabIndex = 2;
            this.lastNamePromptLabel.Text = "Last name:";
            // 
            // firstNameTextBox
            // 
            this.firstNameTextBox.Location = new System.Drawing.Point(96, 47);
            this.firstNameTextBox.Name = "firstNameTextBox";
            this.firstNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.firstNameTextBox.TabIndex = 3;
            // 
            // middleNameTextBox
            // 
            this.middleNameTextBox.Location = new System.Drawing.Point(96, 77);
            this.middleNameTextBox.Name = "middleNameTextBox";
            this.middleNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.middleNameTextBox.TabIndex = 4;
            // 
            // lastNameTextBox
            // 
            this.lastNameTextBox.Location = new System.Drawing.Point(96, 107);
            this.lastNameTextBox.Name = "lastNameTextBox";
            this.lastNameTextBox.Size = new System.Drawing.Size(100, 20);
            this.lastNameTextBox.TabIndex = 5;
            // 
            // formattedNameLabel
            // 
            this.formattedNameLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.formattedNameLabel.Location = new System.Drawing.Point(30, 199);
            this.formattedNameLabel.Name = "formattedNameLabel";
            this.formattedNameLabel.Size = new System.Drawing.Size(184, 23);
            this.formattedNameLabel.TabIndex = 8;
            this.formattedNameLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // formattedNameButton
            // 
            this.formattedNameButton.Location = new System.Drawing.Point(7, 228);
            this.formattedNameButton.Name = "formattedNameButton";
            this.formattedNameButton.Size = new System.Drawing.Size(75, 34);
            this.formattedNameButton.TabIndex = 9;
            this.formattedNameButton.Text = "Format Name";
            this.formattedNameButton.UseVisualStyleBackColor = true;
            this.formattedNameButton.Click += new System.EventHandler(this.formattedNameButton_Click);
            // 
            // clearButton
            // 
            this.clearButton.Location = new System.Drawing.Point(83, 228);
            this.clearButton.Name = "clearButton";
            this.clearButton.Size = new System.Drawing.Size(75, 34);
            this.clearButton.TabIndex = 10;
            this.clearButton.Text = "Clear";
            this.clearButton.UseVisualStyleBackColor = true;
            this.clearButton.Click += new System.EventHandler(this.clearButton_Click);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(160, 228);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 34);
            this.exitButton.TabIndex = 11;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click);
            // 
            // nameFormattedLabel
            // 
            this.nameFormattedLabel.AutoSize = true;
            this.nameFormattedLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nameFormattedLabel.Location = new System.Drawing.Point(56, 178);
            this.nameFormattedLabel.Name = "nameFormattedLabel";
            this.nameFormattedLabel.Size = new System.Drawing.Size(127, 16);
            this.nameFormattedLabel.TabIndex = 12;
            this.nameFormattedLabel.Text = "Formatted Name:";
            // 
            // titlePromptLabel
            // 
            this.titlePromptLabel.AutoSize = true;
            this.titlePromptLabel.Location = new System.Drawing.Point(13, 20);
            this.titlePromptLabel.Name = "titlePromptLabel";
            this.titlePromptLabel.Size = new System.Drawing.Size(30, 13);
            this.titlePromptLabel.TabIndex = 13;
            this.titlePromptLabel.Text = "Title:";
            // 
            // titleComboBox
            // 
            this.titleComboBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.titleComboBox.FormattingEnabled = true;
            this.titleComboBox.Items.AddRange(new object[] {
            "Mr.",
            "Ms.",
            "Miss",
            "Mr.",
            "Dr."});
            this.titleComboBox.Location = new System.Drawing.Point(96, 17);
            this.titleComboBox.Name = "titleComboBox";
            this.titleComboBox.Size = new System.Drawing.Size(100, 22);
            this.titleComboBox.TabIndex = 14;
            this.titleComboBox.Text = "Choose Title:";
            // 
            // formatComboBox
            // 
            this.formatComboBox.Font = new System.Drawing.Font("Microsoft YaHei UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.formatComboBox.FormattingEnabled = true;
            this.formatComboBox.Items.AddRange(new object[] {
            "Title First Middle Last",
            "First Middle Last",
            "First Last",
            "Last, First Middle, Title",
            "Last, First Middle",
            "Last, First"});
            this.formatComboBox.Location = new System.Drawing.Point(30, 142);
            this.formatComboBox.Name = "formatComboBox";
            this.formatComboBox.Size = new System.Drawing.Size(184, 22);
            this.formatComboBox.TabIndex = 15;
            this.formatComboBox.Text = "Choose name format:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(244, 269);
            this.Controls.Add(this.formatComboBox);
            this.Controls.Add(this.titleComboBox);
            this.Controls.Add(this.titlePromptLabel);
            this.Controls.Add(this.nameFormattedLabel);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.clearButton);
            this.Controls.Add(this.formattedNameButton);
            this.Controls.Add(this.formattedNameLabel);
            this.Controls.Add(this.lastNameTextBox);
            this.Controls.Add(this.middleNameTextBox);
            this.Controls.Add(this.firstNameTextBox);
            this.Controls.Add(this.lastNamePromptLabel);
            this.Controls.Add(this.middleNamePromptLabel);
            this.Controls.Add(this.firstNamePromptLabel);
            this.Name = "Form1";
            this.Text = "Name Formatter";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label firstNamePromptLabel;
        private System.Windows.Forms.Label middleNamePromptLabel;
        private System.Windows.Forms.Label lastNamePromptLabel;
        private System.Windows.Forms.TextBox firstNameTextBox;
        private System.Windows.Forms.TextBox middleNameTextBox;
        private System.Windows.Forms.TextBox lastNameTextBox;
        private System.Windows.Forms.Label formattedNameLabel;
        private System.Windows.Forms.Button formattedNameButton;
        private System.Windows.Forms.Button clearButton;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.Label nameFormattedLabel;
        private System.Windows.Forms.Label titlePromptLabel;
        private System.Windows.Forms.ComboBox titleComboBox;
        private System.Windows.Forms.ComboBox formatComboBox;
    }
}

