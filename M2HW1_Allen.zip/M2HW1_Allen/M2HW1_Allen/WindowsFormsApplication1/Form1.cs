﻿/**
* 02/07/2018
* CSC 153
* Nicholas M. Allen
* Formats users name based on their input
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void clearButton_Click(object sender, EventArgs e)
        {
            // This will reset the textboxes and labels to original values
            firstNameTextBox.Text = "";
            middleNameTextBox.Text = "";
            lastNameTextBox.Text = "";
            formattedNameLabel.Text = "";
            titleComboBox.Text = "Choose Title:";
            formatComboBox.Text = "Choose name format:";
        }

        private void formattedNameButton_Click(object sender, EventArgs e)
        {
            // Assigns the variables for the input boxes
            string title, first, middle, last;

            title = titleComboBox.Text;
            first = firstNameTextBox.Text;
            middle = middleNameTextBox.Text;
            last = lastNameTextBox.Text;

            // Lets users decide how they want their name formatted and displays it accordingly
            if (formatComboBox.Text == "Title First Middle Last")
            {
                formattedNameLabel.Text = title + " " + first + " " + middle + " " + last;
            }
            else if (formatComboBox.Text == "First Middle Last")
            {
                formattedNameLabel.Text = first + " " + middle + " " + last;
            }
            else if (formatComboBox.Text == "First Last")
            {
                formattedNameLabel.Text = first + " " + last;
            }
            else if (formatComboBox.Text == "Last, First Middle, Title")
            {
                formattedNameLabel.Text = last + ", " + first + " " + middle + ", " + title;
            }
            else if (formatComboBox.Text == "Last, First Middle")
            {
                formattedNameLabel.Text = last + ", " + first + " " + middle;
            }
            else if (formatComboBox.Text == "Last, First")
            {
                formattedNameLabel.Text = last + ", " + first;
            }
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Lets user close the form
            this.Close();
        }
    }
}
