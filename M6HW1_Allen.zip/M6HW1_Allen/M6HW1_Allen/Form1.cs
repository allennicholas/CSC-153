﻿/**
* 04/16/2018
* CSC 153
* Nicholas M. Allen
* Calculates distance in meters object fell
*/

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace M6HW1_Allen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private double fallingDistance(double seconds)
        {
            double GRAVITY = 9.8;
            double distance = 0.0;
            double time = 0.0;
            double gravTime = 0.0;

            // Square time
            time = Math.Pow(Convert.ToDouble(seconds), 2);

            // Multiple Gravity by Time
            gravTime = GRAVITY * time;

            // Multiplay gravity and time by 0.5
            distance = 0.5 * gravTime;

            // Return distance
            return distance;
        }

        private void exitButton_Click(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }

        private void calculateButton_Click(object sender, EventArgs e)
        {
            double seconds = 0.0;
            double distance = 0.0;
            
            // Convert input to double
            seconds = Convert.ToDouble(secondsTextBox.Text);

            // Pass seconds to fallingDistance method
            fallingDistance(seconds);

            // Get distance back from fallingDistance method
            distance = fallingDistance(seconds);

            // Display distance in meters
            MessageBox.Show("The object fell " + distance + " meters.");
        }
    }
}
